import { createRouter, createWebHistory } from "vue-router"
import store from "../utils/store"

const routes = [
    {
        path: '/',
        children: [
            {
                path: '/',
                component: () => import('../components/Personal.vue')
            },
            {
                path: 'User',
                component: () => import('../components/Personal.vue')
            },
            {
                path: 'Sign',
                component: () => import('../components/Sign.vue')
            },
            {
                path: 'Login',
                component: () => import('../components/login.vue')
            }
        ]
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

// 检查本地存储是否存在token，若存在则直接使用
if (localStorage.getItem("token")) {
    store.commit("setToken", localStorage.getItem("token"));
}

router.beforeEach((to, from, next) => {
    if (to.path === '/Login') next();
    if (!store.getters.GetToken){
        console.log('未检测到登录TOKEN, 转向登录页！')
        next({path: 'Login' })
    } else {
        next()
    };
});

export default router