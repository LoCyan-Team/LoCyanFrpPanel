<template>
<n-alert title="Welcome" type="info" closable style="margin-left: 20px;margin-top: 20px;">
  欢迎来到LoCyanFrp新后台!
  <br>
  公告：{{ contents.contents }}
</n-alert>
  <n-card title="个人信息">
    <span>您好，尊敬的 <a id="username">{{ username }}</a></span>
    <br>
    <span>您的邮箱为：{{ email }}</span>
    <br>
    <spam>速度限制：{{ outbound }} / {{ inbound }}</spam>
    <br>
    <spam>访问秘钥：{{ frptoken }}</spam>
  </n-card>
</template>

<style scoped>
.n-card {
  max-width: 500px;
  margin-left: 30px;
  margin-top: 30px;
}

#username {
  color: hsl(199, 100%, 50%);
  font-size: 20px;
}
</style>

<script setup>
import { NCard, NAlert, NButton, useMessage} from "naive-ui"
import { GetContents } from "../utils/profile.js"
import { ref } from "vue";
import store from "../utils/store.js";
import router from "../router/index.js";

const username = store.getters.GetUserName;
const email = store.getters.GetEmail;
const inbound = store.getters.GetInBound + "Mbps 下行";
const outbound = store.getters.GetOutBound + "Mbps 上行";
const frptoken = store.getters.GetFrpToken;
const contents = GetContents();
const message = useMessage();

</script>