<template>
    <n-space vertical>
        <n-card title="每日签到" size="large">
            通过签到你可以获得更多流量
        </n-card>
    </n-space>
</template>

<script setup>

import { NSpace } from "naive-ui"
import { NCard } from "naive-ui"

</script>

<style scoped>
.n-card {
    max-width: 1100px;
    margin-left: 30px;
    margin-top: 30px;
}

</style>