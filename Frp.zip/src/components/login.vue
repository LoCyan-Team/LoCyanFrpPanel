<template>
  <n-form
    ref="formRef"
    :model="model"
    :rules="rules"
    label-placement="left"
    label-width="auto"
    require-mark-placement="right-hanging"
    :size=large
    :style="{
      maxWidth: '640px',
      position: 'fixed',
      top: '45%',
      left: '45%'
    }"
  >
    <n-form-item label="用户名 / 邮箱" path="username">
      <n-input type="text" v-model:value="model.username" placeholder="Input" />
    </n-form-item>
    <n-form-item label="密码" path="password">
      <n-input type="password" v-model:value="model.password" placeholder="Input" />
    </n-form-item>
    <div style="display: flex; justify-content: flex-end">
      <n-button round type="primary" @click="login"> 登录! </n-button>
    </div>
  </n-form>
</template>

<script setup>
import { ref } from "vue";
import { NFormItem, NForm, NInput, NButton, useMessage, useLoadingBar } from "naive-ui";
import { get, post } from "../utils/request.js";
import router from "../router/index.js";
import qs from 'qs';
import store from "../utils/store.js";

const formRef = ref(null);
const message = useMessage();
const ldb = useLoadingBar();

const model = ref([
  {
    username: "",
    password: ""
  }
]);

function login(e) {
    ldb.start();
    const rs = get("https://api.locyanfrp.cn/User/DoLogin?" + qs.stringify(model.value));
    rs.then(res => {
      if (res.status == 0){
        message.success("欢迎回来，指挥官！" + model.value.username);
        store.commit("setToken", res.token);
        store.commit("setUserInfo", res.userdata);
        router.push("/User");
        console.log(store.getters.GetToken);
      } else {
        message.warning(res.message);
      };
      ldb.finish();
    });
};

const rules = {
  username: {
    required: true,
    trigger: ["blur", "input"],
    message: "请输入用户名",
  },
  password: {
    required: true,
    trigger: ["blur", "input"],
    message: "请输入密码",
  },
};
</script>

<style>
</style>